#!/bin/sh

for MATRIX in SPE10 100
do
    for ORDERING in Sans#Ordering Nested#Dissection
    do
        for ILU in `seq 0 2`
        do
            for ALGO in Seq NOAgg F#8 F#16 F#24 F#32
            do
                echo -n -e "$MATRIX $ORDERING ILU$ILU $ALGO;"
                echo "select AVG(time) from TBB where  MATRIX=\"$MATRIX\" AND ORDERING=\"$ORDERING\" AND ILU=$ILU AND algo=\"$ALGO\" AND schema=\"factorize\"; select AVG(time) from TBB where  MATRIX=\"$MATRIX\" AND ORDERING=\"$ORDERING\" AND ILU=$ILU AND algo=\"$ALGO\" AND schema=\"solve\"; select AVG(time) from TBB where  MATRIX=\"$MATRIX\" AND ORDERING=\"$ORDERING\" AND ILU=$ILU AND algo=\"$ALGO\" AND schema=\"triangular\";" | sqlite3 db.sqlite | sed ':a;N;$!ba;s/\n/;/g'
            done
        done
    done
done
