#!/bin/sh

for MATRIX in SPE10 100
do
    for ORDERING in Nested#Dissection
    do
        for ILU in `seq 0 2`
        do
            for ALGO in 2#50 2#100 2#200 2#400
            do
                echo -n -e "$MATRIX $ORDERING ILU$ILU $ALGO;"
                echo "select AVG(time) from TBB where  MATRIX=\"$MATRIX\" AND ORDERING=\"$ORDERING\" AND ILU=$ILU AND algo=\"$ALGO\" AND schema=\"factorize\"; select AVG(time) from TBB where  MATRIX=\"$MATRIX\" AND ORDERING=\"$ORDERING\" AND ILU=$ILU AND algo=\"$ALGO\" AND schema=\"solve\"; select AVG(time) from TBB where  MATRIX=\"$MATRIX\" AND ORDERING=\"$ORDERING\" AND ILU=$ILU AND algo=\"$ALGO\" AND schema=\"triangular\";" | sqlite3 db.sqlite | sed ':a;N;$!ba;s/\n/;/g'
            done
        done
    done
done
