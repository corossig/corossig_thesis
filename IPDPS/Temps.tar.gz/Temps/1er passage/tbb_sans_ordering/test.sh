#!/bin/sh

database=$PWD/db.sqlite

for MATRIX in `find -maxdepth 1 -type d -name "??*"`
do
    pushd $MATRIX
    for ORDERING in `find -maxdepth 1 -type d -name "??*"`
    do
        pushd $ORDERING
        for ILU in `find -maxdepth 1 -type d -name "??*"`
        do
            pushd $ILU
            for ALGO in `find -maxdepth 1 -type d -name "??*"`
            do
                pushd $ALGO
                echo "Algo : $ALGO"
                for f in *.err
                do
                    awk 'BEGIN { FS=" " }
$4 == "factorize" { print "\"factorize\", " $6 }
$4 == "solve" { print "\"solve\", " $6 }
$2 == "Triangular" { print "\"triangular\", " $6 }' $f > res.txt
                    cat res.txt
                    rm -f cmd.txt
                    while read line
                    do
                        echo "insert into TBB values(\"${MATRIX:2}\", \"${ORDERING:2}\", ${ILU:5}, \"${ALGO:2}\", $line);" >> cmd.txt
                    done < res.txt
                    echo "----------------------------------------------"
                    cat cmd.txt
                    sqlite3 $database < cmd.txt
                done
                popd
            done
            popd
        done
        popd
    done
    popd
done
